#pragma once
#include <iostream>
#include <vector>
#include<fstream>
#include <algorithm>
#include<iomanip>
using namespace std;
vector<string> split(string s, char c);

vector<int>toInt(vector<string>s);
